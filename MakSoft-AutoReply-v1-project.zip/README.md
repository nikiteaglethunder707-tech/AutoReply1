# MakSoft's AutoReply – v1.0.0

WhatsApp / WhatsApp Business auto-reply app (Kotlin, Jetpack Compose, Room).

## Build the APK without installing anything
1. Create a free GitHub account and a new **private** repository.
2. Upload ALL files of this project (drag & drop on the repository page, including the hidden `.github` folder).
3. Open the **Actions** tab -> "Build APK" -> wait ~5-10 minutes.
4. Open the finished run -> **Artifacts** -> download `MakSofts-AutoReply-APK` (zip) -> extract -> `app-debug.apk`.
5. Copy the APK to your phone and install it.

package com.maksoft.autoreply

import android.app.Application
import com.maksoft.autoreply.data.Prefs

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }
}

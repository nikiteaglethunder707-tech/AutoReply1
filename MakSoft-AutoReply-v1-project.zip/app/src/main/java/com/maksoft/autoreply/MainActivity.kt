package com.maksoft.autoreply

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.NotificationManagerCompat
import com.maksoft.autoreply.ui.AppRoot
import com.maksoft.autoreply.ui.AppTheme
import com.maksoft.autoreply.ui.MainViewModel

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private val accessGranted = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                AppRoot(
                    vm = vm,
                    accessGranted = accessGranted.value,
                    onOpenAccess = { openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) },
                    onOpenAppInfo = {
                        startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                .setData(android.net.Uri.parse("package:$packageName"))
                        )
                    },
                    onOpenBattery = { openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        accessGranted.value =
            NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
    }

    private fun openSettings(action: String) {
        runCatching { startActivity(Intent(action)) }
    }
}

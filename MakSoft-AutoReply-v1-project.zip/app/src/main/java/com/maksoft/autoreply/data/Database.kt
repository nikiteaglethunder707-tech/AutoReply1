package com.maksoft.autoreply.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface RuleDao {
    @Query("SELECT * FROM rules ORDER BY priority DESC, id ASC")
    fun observeRules(): Flow<List<Rule>>

    @Query("SELECT * FROM rules WHERE enabled = 1 ORDER BY priority DESC, id ASC")
    suspend fun enabledRules(): List<Rule>

    @Query("SELECT COUNT(*) FROM rules WHERE enabled = 1")
    fun observeActiveCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(rule: Rule): Long

    @Delete
    suspend fun delete(rule: Rule)
}

@Dao
interface LogDao {
    @Insert
    suspend fun insert(log: ReplyLog)

    @Query("SELECT * FROM reply_log ORDER BY time DESC LIMIT 200")
    fun observe(): Flow<List<ReplyLog>>

    @Query("SELECT COUNT(*) FROM reply_log WHERE status = 'SENT'")
    fun observeSentCount(): Flow<Int>

    @Query("SELECT MAX(time) FROM reply_log WHERE sender = :sender AND ruleId = :ruleId AND status = 'SENT'")
    suspend fun lastSent(sender: String, ruleId: Long): Long?

    @Query("DELETE FROM reply_log")
    suspend fun clear()
}

@Database(entities = [Rule::class, ReplyLog::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun rules(): RuleDao
    abstract fun log(): LogDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "autoreply.db"
                ).build().also { instance = it }
            }
    }
}

package com.maksoft.autoreply.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MatchType(val label: String, val hint: String) {
    EXACT("Exact message", "Whole message must be exactly the keyword"),
    CONTAINS("Contains", "Message contains the keyword anywhere"),
    STARTS_WITH("Starts with", "Message begins with the keyword"),
    ENDS_WITH("Ends with", "Message ends with the keyword")
}

@Entity(tableName = "rules")
data class Rule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String = "",
    /** Keywords separated by comma or new line. */
    val keywords: String = "",
    val matchType: String = MatchType.CONTAINS.name,
    /** true = every keyword must match, false = any keyword. */
    val matchAll: Boolean = false,
    val caseSensitive: Boolean = false,
    /** Alternative replies joined with SEP. One is picked at random. */
    val responses: String = "",
    val enabled: Boolean = true,
    val priority: Int = 0,
    val delaySec: Int = 2,
    /** Minimum minutes between replies to the same contact for this rule. 0 = always reply. */
    val cooldownMin: Int = 5,
    val replyGroups: Boolean = false,
    val whatsapp: Boolean = true,
    val business: Boolean = true
) {
    fun type(): MatchType =
        runCatching { MatchType.valueOf(matchType) }.getOrDefault(MatchType.CONTAINS)

    fun keywordList(): List<String> =
        keywords.split(Regex("[,\\n]")).map { it.trim() }.filter { it.isNotEmpty() }

    fun responseList(): List<String> =
        responses.split(SEP).filter { it.isNotBlank() }

    companion object {
        const val SEP = "\u001F"
    }
}

@Entity(tableName = "reply_log")
data class ReplyLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val time: Long,
    val sender: String,
    val incoming: String,
    val reply: String,
    val ruleId: Long,
    val ruleName: String,
    val app: String,
    /** SENT or FAILED */
    val status: String
)

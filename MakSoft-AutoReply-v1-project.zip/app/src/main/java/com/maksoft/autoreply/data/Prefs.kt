package com.maksoft.autoreply.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

object Prefs {
    private lateinit var sp: SharedPreferences

    private val _master = MutableStateFlow(false)
    private val _whatsapp = MutableStateFlow(true)
    private val _fallbackOn = MutableStateFlow(false)
    private val _fallbackText = MutableStateFlow("")
    private val _received = MutableStateFlow(0)

    val master: StateFlow<Boolean> = _master
    val whatsapp: StateFlow<Boolean> = _whatsapp
    val fallbackOn: StateFlow<Boolean> = _fallbackOn
    val fallbackText: StateFlow<String> = _fallbackText
    val received: StateFlow<Int> = _received

    fun init(context: Context) {
        sp = context.getSharedPreferences("makso_prefs", Context.MODE_PRIVATE)
        _master.value = sp.getBoolean("master", false)
        _whatsapp.value = sp.getBoolean("whatsapp", true)
        _fallbackOn.value = sp.getBoolean("fallback_on", false)
        _fallbackText.value = sp.getString("fallback_text", "") ?: ""
        _received.value = sp.getInt("received", 0)
    }

    fun setMaster(v: Boolean) { sp.edit().putBoolean("master", v).apply(); _master.value = v }
    fun setWhatsapp(v: Boolean) { sp.edit().putBoolean("whatsapp", v).apply(); _whatsapp.value = v }
    fun setFallbackOn(v: Boolean) { sp.edit().putBoolean("fallback_on", v).apply(); _fallbackOn.value = v }
    fun setFallbackText(v: String) { sp.edit().putString("fallback_text", v).apply(); _fallbackText.value = v }

    @Synchronized
    fun incrementReceived() {
        val n = _received.value + 1
        sp.edit().putInt("received", n).apply()
        _received.value = n
    }
}

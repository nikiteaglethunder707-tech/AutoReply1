package com.maksoft.autoreply.engine

import com.maksoft.autoreply.data.MatchType
import com.maksoft.autoreply.data.Rule

object Matcher {

    private fun normalize(s: String): String = s.trim().replace(Regex("\\s+"), " ")

    fun matches(rule: Rule, message: String): Boolean {
        val keywords = rule.keywordList()
        if (keywords.isEmpty()) return false
        val msg = normalize(message).let { if (rule.caseSensitive) it else it.lowercase() }
        val type = rule.type()

        fun test(raw: String): Boolean {
            val k = normalize(raw).let { if (rule.caseSensitive) it else it.lowercase() }
            if (k.isEmpty()) return false
            return when (type) {
                MatchType.EXACT -> msg == k
                MatchType.CONTAINS -> msg.contains(k)
                MatchType.STARTS_WITH -> msg.startsWith(k)
                MatchType.ENDS_WITH -> msg.endsWith(k)
            }
        }
        return if (rule.matchAll) keywords.all { test(it) } else keywords.any { test(it) }
    }

    fun pickResponse(rule: Rule): String? = rule.responseList().randomOrNull()
}

package com.maksoft.autoreply.engine

import android.content.Context
import com.maksoft.autoreply.data.AppDatabase
import com.maksoft.autoreply.data.Prefs

data class Decision(val ruleId: Long, val ruleName: String, val text: String, val delaySec: Int)

object ReplyEngine {
    const val WHATSAPP = "com.whatsapp"
    const val WHATSAPP_BUSINESS = "com.whatsapp.w4b"
    private const val FALLBACK_COOLDOWN_MIN = 60

    /** Returns what to reply, or null when no reply must be sent. */
    suspend fun decide(
        context: Context,
        sender: String,
        message: String,
        isGroup: Boolean,
        pkg: String
    ): Decision? {
        // Mandatory switches: nothing is ever sent when these are OFF.
        if (!Prefs.master.value || !Prefs.whatsapp.value) return null

        val db = AppDatabase.get(context)
        val now = System.currentTimeMillis()

        for (rule in db.rules().enabledRules()) {
            if (isGroup && !rule.replyGroups) continue
            if (pkg == WHATSAPP && !rule.whatsapp) continue
            if (pkg == WHATSAPP_BUSINESS && !rule.business) continue
            if (!Matcher.matches(rule, message)) continue

            // First matching rule (highest priority) wins.
            if (rule.cooldownMin > 0) {
                val last = db.log().lastSent(sender, rule.id)
                if (last != null && now - last < rule.cooldownMin * 60_000L) return null
            }
            val text = Matcher.pickResponse(rule) ?: continue
            return Decision(rule.id, rule.name, text, rule.delaySec)
        }

        // Fallback reply (individual chats only)
        val fb = Prefs.fallbackText.value
        if (!isGroup && Prefs.fallbackOn.value && fb.isNotBlank()) {
            val last = db.log().lastSent(sender, 0L)
            if (last == null || now - last >= FALLBACK_COOLDOWN_MIN * 60_000L) {
                return Decision(0L, "Fallback reply", fb, 2)
            }
        }
        return null
    }
}

package com.maksoft.autoreply.service

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import com.maksoft.autoreply.data.AppDatabase
import com.maksoft.autoreply.data.Prefs
import com.maksoft.autoreply.data.ReplyLog
import com.maksoft.autoreply.engine.ReplyEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class ReplyListenerService : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val recent = HashMap<String, Long>()

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        runCatching {
            requestRebind(ComponentName(this, ReplyListenerService::class.java))
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg != ReplyEngine.WHATSAPP && pkg != ReplyEngine.WHATSAPP_BUSINESS) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val extras = n.extras ?: return
        var sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        var text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()

        // Prefer the newest message of a MessagingStyle bundle
        @Suppress("DEPRECATION")
        val msgs = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
        val last = msgs?.lastOrNull() as? Bundle
        last?.getCharSequence("text")?.toString()?.let { if (it.isNotBlank()) text = it.trim() }

        if (sender.isEmpty() || text.isEmpty()) return

        // Ignore WhatsApp summary / system notifications
        val summaryRegex = Regex("^\\d+ (new )?messages?.*", RegexOption.IGNORE_CASE)
        if (summaryRegex.matches(text) || text.contains("Checking for new messages", true)) return

        val countSuffix = Regex("\\s*\\(\\d+ messages?\\)$")
        val isGroup = extras.getBoolean("android.isGroupConversation", false) ||
            (countSuffix.containsMatchIn(sender) && text.contains(": "))
        sender = sender.replace(countSuffix, "")

        // Duplicate-notification guard
        val key = "$pkg|$sender|$text"
        val now = System.currentTimeMillis()
        synchronized(recent) {
            recent.entries.removeAll { now - it.value > 60_000L }
            val seen = recent[key]
            if (seen != null && now - seen < 10_000L) return
            recent[key] = now
        }

        Prefs.incrementReceived()

        val sendFn = findReplySender(n)
        val incoming = text
        val who = sender

        scope.launch {
            val decision = ReplyEngine.decide(applicationContext, who, incoming, isGroup, pkg) ?: return@launch
            val db = AppDatabase.get(applicationContext)
            val appName = if (pkg == ReplyEngine.WHATSAPP_BUSINESS) "WhatsApp Business" else "WhatsApp"

            if (sendFn == null) {
                db.log().insert(
                    ReplyLog(
                        time = System.currentTimeMillis(), sender = who, incoming = incoming,
                        reply = decision.text, ruleId = decision.ruleId, ruleName = decision.ruleName,
                        app = appName, status = "FAILED"
                    )
                )
                return@launch
            }

            if (decision.delaySec > 0) delay(decision.delaySec * 1000L)

            // Re-check switches after the delay: user may have turned automation OFF meanwhile.
            if (!Prefs.master.value || !Prefs.whatsapp.value) return@launch

            val ok = runCatching { sendFn(decision.text) }.isSuccess
            db.log().insert(
                ReplyLog(
                    time = System.currentTimeMillis(), sender = who, incoming = incoming,
                    reply = decision.text, ruleId = decision.ruleId, ruleName = decision.ruleName,
                    app = appName, status = if (ok) "SENT" else "FAILED"
                )
            )
        }
    }

    /** Finds the notification's inline "Reply" action and returns a function that sends text through it. */
    private fun findReplySender(n: Notification): ((String) -> Unit)? {
        n.actions?.forEach { a ->
            val inputs = a.remoteInputs
            val pi = a.actionIntent
            if (inputs != null && inputs.isNotEmpty() && pi != null) {
                val semanticReply = Build.VERSION.SDK_INT >= 28 &&
                    a.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY
                val titleReply = a.title?.toString()?.contains("reply", ignoreCase = true) == true
                if (semanticReply || titleReply) {
                    return { reply -> fire(pi, inputs, reply) }
                }
            }
        }
        // Wearable extender fallback
        val wearActions = NotificationCompat.WearableExtender(n).actions
        for (a in wearActions) {
            val inputs = a.remoteInputs
            val pi = a.actionIntent
            if (inputs != null && inputs.isNotEmpty() && pi != null) {
                return { reply -> fireCompat(pi, inputs, reply) }
            }
        }
        return null
    }

    private fun fire(pi: PendingIntent, inputs: Array<RemoteInput>, reply: String) {
        val intent = Intent()
        val bundle = Bundle()
        for (ri in inputs) bundle.putCharSequence(ri.resultKey, reply)
        RemoteInput.addResultsToIntent(inputs, intent, bundle)
        pi.send(this, 0, intent)
    }

    private fun fireCompat(pi: PendingIntent, inputs: Array<androidx.core.app.RemoteInput>, reply: String) {
        val intent = Intent()
        val bundle = Bundle()
        for (ri in inputs) bundle.putCharSequence(ri.resultKey, reply)
        androidx.core.app.RemoteInput.addResultsToIntent(inputs, intent, bundle)
        pi.send(this, 0, intent)
    }
}

package com.maksoft.autoreply.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.maksoft.autoreply.data.AppDatabase
import com.maksoft.autoreply.data.ReplyLog
import com.maksoft.autoreply.data.Rule
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)

    val rules: StateFlow<List<Rule>> = db.rules().observeRules()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val logs: StateFlow<List<ReplyLog>> = db.log().observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sentCount: StateFlow<Int> = db.log().observeSentCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val activeRules: StateFlow<Int> = db.rules().observeActiveCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun saveRule(rule: Rule) { viewModelScope.launch { db.rules().upsert(rule) } }
    fun deleteRule(rule: Rule) { viewModelScope.launch { db.rules().delete(rule) } }
    fun toggleRule(rule: Rule, on: Boolean) { viewModelScope.launch { db.rules().upsert(rule.copy(enabled = on)) } }
    fun duplicateRule(rule: Rule) {
        viewModelScope.launch { db.rules().upsert(rule.copy(id = 0, name = rule.name + " (copy)")) }
    }
    fun clearLogs() { viewModelScope.launch { db.log().clear() } }
}

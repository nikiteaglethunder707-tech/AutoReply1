@file:OptIn(ExperimentalMaterial3Api::class)

package com.maksoft.autoreply.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import com.maksoft.autoreply.data.MatchType
import com.maksoft.autoreply.data.Rule
import com.maksoft.autoreply.engine.Matcher

@Composable
fun RuleEditor(initial: Rule, onSave: (Rule) -> Unit, onCancel: () -> Unit) {
    var name by remember { mutableStateOf(initial.name) }
    var keywords by remember { mutableStateOf(initial.keywords) }
    var matchType by remember { mutableStateOf(initial.type()) }
    var matchAll by remember { mutableStateOf(initial.matchAll) }
    var caseSensitive by remember { mutableStateOf(initial.caseSensitive) }
    val responses = remember {
        mutableStateListOf<String>().apply { addAll(initial.responseList().ifEmpty { listOf("") }) }
    }
    var enabled by remember { mutableStateOf(initial.enabled) }
    var priority by remember { mutableStateOf(initial.priority.toString()) }
    var delaySec by remember { mutableStateOf(initial.delaySec.toString()) }
    var cooldown by remember { mutableStateOf(initial.cooldownMin.toString()) }
    var groups by remember { mutableStateOf(initial.replyGroups) }
    var whatsapp by remember { mutableStateOf(initial.whatsapp) }
    var business by remember { mutableStateOf(initial.business) }
    var testText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    fun build(): Rule = initial.copy(
        name = name.trim(),
        keywords = keywords,
        matchType = matchType.name,
        matchAll = matchAll,
        caseSensitive = caseSensitive,
        responses = responses.map { it.trim() }.filter { it.isNotEmpty() }.joinToString(Rule.SEP),
        enabled = enabled,
        priority = priority.toIntOrNull() ?: 0,
        delaySec = (delaySec.toIntOrNull() ?: 0).coerceIn(0, 120),
        cooldownMin = (cooldown.toIntOrNull() ?: 0).coerceAtLeast(0),
        replyGroups = groups,
        whatsapp = whatsapp,
        business = business
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(if (initial.id == 0L) "New rule" else "Edit rule") },
                navigationIcon = { TextButton(onClick = onCancel) { Text("Cancel", color = Color.White) } },
                actions = {
                    TextButton(onClick = {
                        val r = build()
                        error = when {
                            r.name.isEmpty() -> "Please enter a rule name."
                            r.keywordList().isEmpty() -> "Add at least one keyword."
                            r.responseList().isEmpty() -> "Add at least one reply message."
                            !r.whatsapp && !r.business -> "Select WhatsApp and/or WhatsApp Business."
                            else -> null
                        }
                        if (error == null) onSave(r)
                    }) { Text("Save", color = Color.White) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Blue, titleContentColor = Color.White)
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            error?.let { Text(it, color = Red, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold) }

            SectionCard("1. Rule name") {
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text("e.g. Price enquiry") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Rule enabled", Modifier.weight(1f))
                    Switch(checked = enabled, onCheckedChange = { enabled = it })
                }
            }

            SectionCard("2. When someone sends…") {
                OutlinedTextField(
                    value = keywords, onValueChange = { keywords = it },
                    label = { Text("Keywords / phrases") },
                    supportingText = { Text("Separate several keywords with a comma or a new line") },
                    minLines = 2, modifier = Modifier.fillMaxWidth()
                )
                Text("Match type", fontSize = 13.sp, color = Color.Gray)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf(MatchType.EXACT, MatchType.CONTAINS).forEach { t ->
                        FilterChip(selected = matchType == t, onClick = { matchType = t }, label = { Text(t.label) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf(MatchType.STARTS_WITH, MatchType.ENDS_WITH).forEach { t ->
                        FilterChip(selected = matchType == t, onClick = { matchType = t }, label = { Text(t.label) })
                    }
                }
                Text(matchType.hint, fontSize = 12.sp, color = Color.Gray)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Match ALL keywords")
                        Text("OFF = any one keyword is enough", fontSize = 11.sp, color = Color.Gray)
                    }
                    Switch(checked = matchAll, onCheckedChange = { matchAll = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Case sensitive", Modifier.weight(1f))
                    Switch(checked = caseSensitive, onCheckedChange = { caseSensitive = it })
                }
            }

            SectionCard("3. Reply with…") {
                responses.forEachIndexed { i, text ->
                    Row(verticalAlignment = Alignment.Top) {
                        OutlinedTextField(
                            value = text, onValueChange = { responses[i] = it },
                            label = { Text(if (responses.size > 1) "Reply ${i + 1}" else "Reply message") },
                            minLines = 2, modifier = Modifier.weight(1f)
                        )
                        if (responses.size > 1) {
                            IconButton(onClick = { responses.removeAt(i) }) { Icon(Icons.Filled.Close, "Remove") }
                        }
                    }
                }
                TextButton(onClick = { responses.add("") }) {
                    Icon(Icons.Filled.Add, null)
                    Spacer(Modifier.size(6.dp))
                    Text("Add another reply")
                }
                if (responses.size > 1) {
                    Text("With several replies, one is chosen at random each time.", fontSize = 12.sp, color = Color.Gray)
                }
            }

            SectionCard("4. Options") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = delaySec, onValueChange = { delaySec = it.filter(Char::isDigit).take(3) },
                        label = { Text("Delay (sec)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = cooldown, onValueChange = { cooldown = it.filter(Char::isDigit).take(5) },
                        label = { Text("Once per (min)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
                Text("\"Once per\" = don't reply to the same contact with this rule again within these minutes. 0 = reply every time.", fontSize = 12.sp, color = Color.Gray)
                OutlinedTextField(
                    value = priority, onValueChange = { priority = it.filter { c -> c.isDigit() || c == '-' }.take(4) },
                    label = { Text("Priority (higher runs first)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Reply in WhatsApp", Modifier.weight(1f))
                    Switch(checked = whatsapp, onCheckedChange = { whatsapp = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Reply in WhatsApp Business", Modifier.weight(1f))
                    Switch(checked = business, onCheckedChange = { business = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Also reply in groups")
                        Text("Off by default to avoid spamming groups", fontSize = 11.sp, color = Color.Gray)
                    }
                    Switch(checked = groups, onCheckedChange = { groups = it })
                }
            }

            SectionCard("Test this rule") {
                OutlinedTextField(
                    value = testText, onValueChange = { testText = it },
                    label = { Text("Type a sample incoming message") }, modifier = Modifier.fillMaxWidth()
                )
                if (testText.isNotBlank()) {
                    val ok = Matcher.matches(build(), testText)
                    Text(
                        if (ok) "✓ This message WOULD trigger the rule" else "✗ This message would NOT trigger the rule",
                        color = if (ok) Green else Red,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = Blue)
            content()
        }
    }
}

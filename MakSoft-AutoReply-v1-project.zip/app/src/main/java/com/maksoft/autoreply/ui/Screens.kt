@file:OptIn(ExperimentalMaterial3Api::class)

package com.maksoft.autoreply.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.maksoft.autoreply.data.Prefs
import com.maksoft.autoreply.data.ReplyLog
import com.maksoft.autoreply.data.Rule
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class NavItem(val label: String, val icon: ImageVector)

@Composable
fun AppRoot(
    vm: MainViewModel,
    accessGranted: Boolean,
    onOpenAccess: () -> Unit,
    onOpenAppInfo: () -> Unit,
    onOpenBattery: () -> Unit
) {
    var editing by remember { mutableStateOf<Rule?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    BackHandler(enabled = editing != null) { editing = null }

    val current = editing
    if (current != null) {
        RuleEditor(
            initial = current,
            onSave = { vm.saveRule(it); editing = null },
            onCancel = { editing = null }
        )
        return
    }

    val items = listOf(
        NavItem("Home", Icons.Filled.Home),
        NavItem("Rules", Icons.Filled.Chat),
        NavItem("History", Icons.Filled.History),
        NavItem("Settings", Icons.Filled.Settings)
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                items.forEachIndexed { i, item ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(vm, accessGranted, onOpenAccess, onNewRule = { editing = Rule() }, onSeeAllRules = { tab = 1 })
                1 -> RulesScreen(vm, onNew = { editing = Rule() }, onEdit = { editing = it })
                2 -> HistoryScreen(vm)
                else -> SettingsScreen(accessGranted, onOpenAccess, onOpenAppInfo, onOpenBattery)
            }
        }
    }
}

// ───────────────────────── Home ─────────────────────────

@Composable
fun HomeScreen(
    vm: MainViewModel,
    accessGranted: Boolean,
    onOpenAccess: () -> Unit,
    onNewRule: () -> Unit,
    onSeeAllRules: () -> Unit
) {
    val master by Prefs.master.collectAsState()
    val whatsapp by Prefs.whatsapp.collectAsState()
    val received by Prefs.received.collectAsState()
    val sent by vm.sentCount.collectAsState()
    val active by vm.activeRules.collectAsState()
    val logs by vm.logs.collectAsState()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        // Header
        Box(
            Modifier.fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(Blue, BlueDark)))
                .padding(horizontal = 20.dp, vertical = 22.dp)
        ) {
            Column {
                Text("MakSoft's AutoReply", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("Smart automatic replies for WhatsApp", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
            }
        }

        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (!accessGranted) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Warning, null, tint = Orange)
                            Spacer(Modifier.size(8.dp))
                            Text("Notification access required", fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("Allow notification access so the app can see WhatsApp messages and reply to them.", fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = onOpenAccess, colors = ButtonDefaults.buttonColors(containerColor = Orange)) {
                            Text("Enable now")
                        }
                    }
                }
            }

            SwitchCard(
                title = "Master Auto Reply",
                subtitle = if (master) "ON – automatic replies are active" else "OFF – no automatic reply will be sent",
                checked = master,
                onChecked = { Prefs.setMaster(it) },
                big = true
            )
            SwitchCard(
                title = "WhatsApp Auto Reply",
                subtitle = when {
                    !master -> "Paused by Master switch"
                    whatsapp -> "ON – replying to WhatsApp messages"
                    else -> "OFF"
                },
                checked = whatsapp,
                onChecked = { Prefs.setWhatsapp(it) }
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Received", received.toString(), Modifier.weight(1f))
                StatCard("Replies sent", sent.toString(), Modifier.weight(1f))
                StatCard("Active rules", active.toString(), Modifier.weight(1f))
            }

            Button(
                onClick = onNewRule,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Orange)
            ) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.size(8.dp))
                Text("Create auto-reply rule", fontWeight = FontWeight.SemiBold)
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Recent activity", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = onSeeAllRules) { Text("My rules") }
            }
            if (logs.isEmpty()) {
                Text("No replies yet.", color = Color.Gray, fontSize = 13.sp)
            } else {
                logs.take(5).forEach { LogCard(it) }
            }
        }
    }
}

@Composable
private fun SwitchCard(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit, big: Boolean = false) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(if (big) 14.dp else 10.dp)
                    .background(if (checked) Green else Color.Gray, RoundedCornerShape(50))
            )
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = if (big) 18.sp else 16.sp)
                Text(subtitle, fontSize = 12.sp, color = Color.Gray)
            }
            Switch(checked = checked, onCheckedChange = onChecked)
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = BlueDark)
            Text(label, fontSize = 12.sp, color = BlueDark)
        }
    }
}

// ───────────────────────── Rules ─────────────────────────

@Composable
fun RulesScreen(vm: MainViewModel, onNew: () -> Unit, onEdit: (Rule) -> Unit) {
    val rules by vm.rules.collectAsState()
    var toDelete by remember { mutableStateOf<Rule?>(null) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Text("Auto-reply rules", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
            if (rules.isEmpty()) {
                Text(
                    "No rules yet. Tap + to create your first rule.\n\nExample: keyword \"price\" → reply \"Our price list is ...\"",
                    color = Color.Gray, modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
            LazyColumn(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(rules, key = { it.id }) { rule ->
                    RuleCard(
                        rule = rule,
                        onToggle = { vm.toggleRule(rule, it) },
                        onEdit = { onEdit(rule) },
                        onDuplicate = { vm.duplicateRule(rule) },
                        onDelete = { toDelete = rule }
                    )
                }
            }
        }
        FloatingActionButton(
            onClick = onNew,
            containerColor = Orange,
            contentColor = Color.White,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
        ) { Icon(Icons.Filled.Add, "Add rule") }
    }

    toDelete?.let { r ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete rule?") },
            text = { Text("\"${r.name}\" will be permanently deleted.") },
            confirmButton = { TextButton(onClick = { vm.deleteRule(r); toDelete = null }) { Text("Delete", color = Red) } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun RuleCard(rule: Rule, onToggle: (Boolean) -> Unit, onEdit: () -> Unit, onDuplicate: () -> Unit, onDelete: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp),
        onClick = onEdit
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(rule.name.ifBlank { "Untitled rule" }, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        "${rule.type().label}: " + rule.keywordList().joinToString(", "),
                        fontSize = 12.sp, color = Blue, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                Switch(checked = rule.enabled, onCheckedChange = onToggle)
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Menu") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Edit") }, onClick = { menu = false; onEdit() })
                        DropdownMenuItem(text = { Text("Duplicate") }, onClick = { menu = false; onDuplicate() })
                        DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete() })
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                rule.responseList().firstOrNull().orEmpty(),
                fontSize = 13.sp, color = Color.DarkGray, maxLines = 2, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// ───────────────────────── History ─────────────────────────

@Composable
fun HistoryScreen(vm: MainViewModel) {
    val logs by vm.logs.collectAsState()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Reply history", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (logs.isNotEmpty()) {
                IconButton(onClick = { vm.clearLogs() }) { Icon(Icons.Filled.Delete, "Clear history") }
            }
        }
        if (logs.isEmpty()) {
            Text("Nothing here yet.", color = Color.Gray, modifier = Modifier.padding(horizontal = 16.dp))
        }
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(logs, key = { it.id }) { LogCard(it) }
        }
    }
}

@Composable
private fun LogCard(log: ReplyLog) {
    val fmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(log.sender, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    if (log.status == "SENT") "Sent" else "Failed",
                    color = if (log.status == "SENT") Green else Red,
                    fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                )
            }
            Text("${log.app} • ${fmt.format(Date(log.time))} • ${log.ruleName}", fontSize = 11.sp, color = Color.Gray)
            Spacer(Modifier.height(6.dp))
            Text("They: ${log.incoming}", fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("Reply: ${log.reply}", fontSize = 13.sp, color = Blue, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ───────────────────────── Settings ─────────────────────────

@Composable
fun SettingsScreen(
    accessGranted: Boolean,
    onOpenAccess: () -> Unit,
    onOpenAppInfo: () -> Unit,
    onOpenBattery: () -> Unit
) {
    val fallbackOn by Prefs.fallbackOn.collectAsState()
    val fallbackText by Prefs.fallbackText.collectAsState()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("WhatsApp setup", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    if (accessGranted) "Notification access: GRANTED" else "Notification access: NOT GRANTED",
                    color = if (accessGranted) Green else Red, fontWeight = FontWeight.SemiBold, fontSize = 13.sp
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "1. Tap the button below and switch ON \"MakSoft's AutoReply\".\n" +
                        "2. If the switch is greyed out (Android 13+), tap \"App info\" → ⋮ menu → \"Allow restricted settings\", then repeat step 1.\n" +
                        "3. Keep WhatsApp notifications enabled, and keep them showing message text.\n" +
                        "4. Turn ON Master Auto Reply on the Home screen.",
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onOpenAccess) { Text("Notification access") }
                    OutlinedButton(onClick = onOpenAppInfo) { Text("App info") }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onOpenBattery) { Text("Battery optimization") }
                Text(
                    "Set this app to \"Unrestricted\" / not optimized so Android doesn't stop it in the background.",
                    fontSize = 12.sp, color = Color.Gray
                )
            }
        }

        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Default (fallback) reply", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Sent when no rule matches (individual chats, once per hour per contact).", fontSize = 12.sp, color = Color.Gray)
                    }
                    Switch(checked = fallbackOn, onCheckedChange = { Prefs.setFallbackOn(it) })
                }
                OutlinedTextField(
                    value = fallbackText,
                    onValueChange = { Prefs.setFallbackText(it) },
                    label = { Text("Fallback message") },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    minLines = 2
                )
            }
        }

        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("Privacy", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Everything stays on your phone. Messages are read only from WhatsApp notifications, matched locally against your rules, and nothing is sent to any server.",
                    fontSize = 13.sp
                )
            }
        }

        Text("MakSoft's AutoReply • Version 1.0.0", fontSize = 12.sp, color = Color.Gray)
    }
}

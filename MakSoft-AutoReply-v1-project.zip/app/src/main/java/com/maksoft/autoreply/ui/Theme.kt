package com.maksoft.autoreply.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Blue = Color(0xFF1565C0)
val BlueDark = Color(0xFF0D47A1)
val Orange = Color(0xFFFF8F00)
val Green = Color(0xFF2E7D32)
val Red = Color(0xFFC62828)

private val scheme = lightColorScheme(
    primary = Blue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4FF),
    onPrimaryContainer = BlueDark,
    secondary = Orange,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE0B2),
    background = Color(0xFFF4F7FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFE9EEF7)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}

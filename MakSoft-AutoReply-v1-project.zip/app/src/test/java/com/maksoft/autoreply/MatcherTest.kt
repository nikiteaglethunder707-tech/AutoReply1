package com.maksoft.autoreply

import com.maksoft.autoreply.data.MatchType
import com.maksoft.autoreply.data.Rule
import com.maksoft.autoreply.engine.Matcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MatcherTest {
    private fun rule(kw: String, type: MatchType, all: Boolean = false, cs: Boolean = false) =
        Rule(keywords = kw, matchType = type.name, matchAll = all, caseSensitive = cs, responses = "ok")

    @Test fun containsAny() {
        val r = rule("admission, course", MatchType.CONTAINS)
        assertTrue(Matcher.matches(r, "Hello, I want ADMISSION information"))
        assertFalse(Matcher.matches(r, "What are your timings?"))
    }

    @Test fun containsAll() {
        val r = rule("price, laptop", MatchType.CONTAINS, all = true)
        assertTrue(Matcher.matches(r, "laptop price please"))
        assertFalse(Matcher.matches(r, "laptop details"))
    }

    @Test fun exact() {
        val r = rule("hi", MatchType.EXACT)
        assertTrue(Matcher.matches(r, "  Hi "))
        assertFalse(Matcher.matches(r, "hi there"))
    }

    @Test fun startsEnds() {
        assertTrue(Matcher.matches(rule("hello", MatchType.STARTS_WITH), "hello team"))
        assertFalse(Matcher.matches(rule("hello", MatchType.STARTS_WITH), "oh hello"))
        assertTrue(Matcher.matches(rule("thanks", MatchType.ENDS_WITH), "ok thanks"))
    }

    @Test fun caseSensitive() {
        assertFalse(Matcher.matches(rule("Hi", MatchType.EXACT, cs = true), "hi"))
        assertTrue(Matcher.matches(rule("Hi", MatchType.EXACT, cs = true), "Hi"))
    }

    @Test fun emptyKeywordsNeverMatch() {
        assertEquals(false, Matcher.matches(rule("  ,\n", MatchType.CONTAINS), "anything"))
    }
}
